import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
status:any=false;
// currentStyle:any;
// canSave:any='100%';
active:any=false;
  constructor() { }
  onClick(){
    this.status=true;
    this.active=true;
    // this.currentStyle = {
    //   'width':  this.canSave? '80%' : '80%',
    //   // 'font-weight': !this.isUnchanged ? 'bold'   : 'normal',
    //   // 'font-size':   this.isSpecial    ? '24px'   : '12px'
    // };
  }

  ngOnInit(): void {
  }

}
