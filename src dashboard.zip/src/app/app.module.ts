import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { SideMenuComponent } from './dashboard/side-menu/side-menu.component';
import { CardComponent } from './dashboard/card/card.component';
import { HomeComponent } from './dashboard/home/home.component';
import { DashboardComponent } from './dashboard/dashboard/dashboard.component';
import { CreateClientComponent } from './dashboard/create-client/create-client.component';

@NgModule({
  declarations: [
    AppComponent,
    SideMenuComponent,
    CardComponent,
    HomeComponent,
    DashboardComponent,
    CreateClientComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
